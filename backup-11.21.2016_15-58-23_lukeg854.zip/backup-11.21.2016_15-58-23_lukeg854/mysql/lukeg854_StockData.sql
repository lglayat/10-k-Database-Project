-- MySQL dump 10.13  Distrib 5.6.28-76.1, for Linux (x86_64)
--
-- Host: localhost    Database: lukeg854_StockData
-- ------------------------------------------------------
-- Server version	5.6.28-76.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Companies`
--

DROP TABLE IF EXISTS `Companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Companies` (
  `companyName` varchar(255) NOT NULL,
  `ticker` varchar(255) NOT NULL,
  `sector` varchar(255) NOT NULL,
  `marketCap` varchar(255) NOT NULL,
  PRIMARY KEY (`ticker`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Companies`
--

LOCK TABLES `Companies` WRITE;
/*!40000 ALTER TABLE `Companies` DISABLE KEYS */;
INSERT INTO `Companies` (`companyName`, `ticker`, `sector`, `marketCap`) VALUES ('Apple','AAPL','Technology','Large'),('American Electric Co','AEP','Utilities','Large'),('Cryolife Inc.','CRY','Healthcare','Small'),('Cisco Systems','CSCO','Technology','Large'),('Chevron Corp','CVX','Basic Materials','Large'),('JP Morgan Chase & Co','JPM','Financial','Large'),('Monsanto','MON','Basic Materials','Large'),('Panera Bread Co','PNRA','Services','Medium'),('Ralph Lauren Corp','RL','Consumer Goods','Large'),('AT&T','T','Technology','Large');
/*!40000 ALTER TABLE `Companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `balanceSheet`
--

DROP TABLE IF EXISTS `balanceSheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balanceSheet` (
  `ticker` varchar(255) NOT NULL,
  `totalAssets` int(11) NOT NULL,
  `totalLiabilities` int(11) NOT NULL,
  `totalEquity` int(11) NOT NULL,
  PRIMARY KEY (`ticker`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balanceSheet`
--

LOCK TABLES `balanceSheet` WRITE;
/*!40000 ALTER TABLE `balanceSheet` DISABLE KEYS */;
INSERT INTO `balanceSheet` (`ticker`, `totalAssets`, `totalLiabilities`, `totalEquity`) VALUES ('AAPL ',321686000,193437000,128249000),('AEP',61683100,43791400,17891700),('CRY',181179,25928,155251),('CSCO',121652000,58066000,63586000),('CVX',266103000,113387000,152716000),('JPM',2147483647,2104125000,247573000),('MON ',19736000,15202000,4534000),('PNRA',1475318,978018,497300),('RL',6213000,2469000,3744000),('T',402672000,122671000,280001000);
/*!40000 ALTER TABLE `balanceSheet` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`lukeg854`@`localhost`*/ /*!50003 TRIGGER `balance_contraint` BEFORE INSERT ON `balanceSheet` FOR EACH ROW IF (new.totalAssets != new.totalLiabilities + new.totalEquity) THEN 
SET new.totalAssets = new.totalLiabilities + new.totalEquity;
END IF */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `cashFlowAudits`
--

DROP TABLE IF EXISTS `cashFlowAudits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cashFlowAudits` (
  `ticker` varchar(255) NOT NULL,
  `financing` int(11) NOT NULL,
  `operating` int(11) NOT NULL,
  `investing` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ticker`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Audit Table for Balance Sheet Insertions';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cashFlowAudits`
--

LOCK TABLES `cashFlowAudits` WRITE;
/*!40000 ALTER TABLE `cashFlowAudits` DISABLE KEYS */;
INSERT INTO `cashFlowAudits` (`ticker`, `financing`, `operating`, `investing`, `time`) VALUES ('AEP',-661700,4748700,-4564000,'2016-11-20 16:48:38'),('CRY',-4486,11442,-2810,'2016-11-20 15:20:55'),('CSCO',-4699000,13,-8117000,'2016-11-20 17:09:44'),('CVX',2815000,19456000,23808000,'2016-11-20 15:30:18'),('JPM',106980000,73466000,-187511000,'2016-11-20 17:01:02'),('MON',92,-90,83,'2016-11-18 15:49:28'),('PNRA',-107237,318,-165415,'2016-11-20 16:35:19'),('RL',-473000,1007000,-583000,'2016-11-20 16:11:42'),('T',9782000,35,-49144000,'2016-11-20 16:24:14'),('VW',4,8,-1,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `cashFlowAudits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cashFlows`
--

DROP TABLE IF EXISTS `cashFlows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cashFlows` (
  `ticker` varchar(255) NOT NULL,
  `operating` int(11) NOT NULL,
  `financing` int(11) NOT NULL,
  `investing` int(11) NOT NULL,
  PRIMARY KEY (`ticker`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cashFlows`
--

LOCK TABLES `cashFlows` WRITE;
/*!40000 ALTER TABLE `cashFlows` DISABLE KEYS */;
INSERT INTO `cashFlows` (`ticker`, `operating`, `financing`, `investing`) VALUES ('AAPL ',65824000,-45977000,20483000),('AEP',4748700,-661700,-4564000),('CRY',11442,-4486,-2810),('CSCO',13,-4699000,-8117000),('CVX',19456000,2815000,23808000),('JPM',73466000,106980000,-187511000),('PNRA ',318045,-107237,-165415),('RL',1007000,-473000,-583000),('T ',35880000,9782000,-49144000);
/*!40000 ALTER TABLE `cashFlows` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`lukeg854`@`localhost`*/ /*!50003 TRIGGER `cashFlowAudits` AFTER INSERT ON `cashFlows` FOR EACH ROW INSERT INTO cashFlowAudits(ticker, financing, investing, operating, time) VALUES(new.ticker, new.financing, new.investing, new.operating, NOW()) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `efficiency`
--

DROP TABLE IF EXISTS `efficiency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `efficiency` (
  `ticker` varchar(255) NOT NULL,
  `assetTurnover` decimal(4,2) NOT NULL,
  `inventoryTurnover` decimal(4,2) NOT NULL,
  `cashConversionCycle` decimal(4,2) NOT NULL,
  PRIMARY KEY (`ticker`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `efficiency`
--

LOCK TABLES `efficiency` WRITE;
/*!40000 ALTER TABLE `efficiency` DISABLE KEYS */;
INSERT INTO `efficiency` (`ticker`, `assetTurnover`, `inventoryTurnover`, `cashConversionCycle`) VALUES ('AAPL ',0.70,58.64,-67.29),('AEP',5.70,0.34,-11.57),('CRY',1.04,7.67,75.58),('CSCO',0.72,9.35,53.00),('CVX',1.63,32.84,-0.12),('MON',0.69,2.51,99.99),('PNRA',1.69,46.66,15.19),('RL',1.25,3.87,99.63),('T',0.30,0.00,37.61);
/*!40000 ALTER TABLE `efficiency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incomeStatement`
--

DROP TABLE IF EXISTS `incomeStatement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incomeStatement` (
  `ticker` varchar(255) NOT NULL,
  `revenue` int(11) NOT NULL,
  `cogs` int(11) NOT NULL,
  `depreciation` int(11) NOT NULL,
  `ebitda` int(11) NOT NULL,
  `netIncome` int(11) NOT NULL,
  PRIMARY KEY (`ticker`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incomeStatement`
--

LOCK TABLES `incomeStatement` WRITE;
/*!40000 ALTER TABLE `incomeStatement` DISABLE KEYS */;
INSERT INTO `incomeStatement` (`ticker`, `revenue`, `cogs`, `depreciation`, `ebitda`, `netIncome`) VALUES ('AAPL ',215639000,131376000,-10505,61372000,45687000),('AEP',16453200,7433500,-2000,3496800,2052300),('CRY',145898,55179,0,5806,4005),('CSCO',49247000,18287000,-2150,13596000,10739000),('CVX ',129925000,92785000,-20654,4842000,4587000),('JPM ',89716000,0,-53050,38165000,24442000),('MON ',13502000,6485000,-498000,2427000,1336000),('PNRA ',2681580,1800852,-144034,240402,149342),('RL ',7405000,3218000,-313000,573000,396000),('T',146801000,67046000,-192339,24812000,13345000);
/*!40000 ALTER TABLE `incomeStatement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `liquidity`
--

DROP TABLE IF EXISTS `liquidity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `liquidity` (
  `ticker` varchar(255) NOT NULL,
  `currentRatio` decimal(4,2) NOT NULL,
  `quickRatio` decimal(4,2) NOT NULL,
  `debtEquity` decimal(4,2) NOT NULL,
  `debtAssets` decimal(4,2) NOT NULL,
  PRIMARY KEY (`ticker`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `liquidity`
--

LOCK TABLES `liquidity` WRITE;
/*!40000 ALTER TABLE `liquidity` DISABLE KEYS */;
INSERT INTO `liquidity` (`ticker`, `currentRatio`, `quickRatio`, `debtEquity`, `debtAssets`) VALUES ('AAPL ',1.35,1.33,0.68,0.56),('AEP',0.57,0.38,0.60,0.30),('CRY',5.59,4.85,0.35,0.46),('CSCO',3.16,3.11,0.45,0.20),('CVX',1.34,1.10,0.31,0.29),('MON ',0.99,0.73,0.60,0.40),('PNRA',1.26,1.20,1.35,0.50),('RL',2.55,1.61,0.27,0.14),('T',0.75,0.68,0.82,0.40);
/*!40000 ALTER TABLE `liquidity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profitability`
--

DROP TABLE IF EXISTS `profitability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profitability` (
  `ticker` varchar(255) NOT NULL,
  `profitMargin` decimal(4,2) NOT NULL,
  `operatingMargin` decimal(4,2) NOT NULL,
  `returnOnAssets` decimal(4,2) NOT NULL,
  `returnOnEquity` decimal(4,2) NOT NULL,
  PRIMARY KEY (`ticker`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profitability`
--

LOCK TABLES `profitability` WRITE;
/*!40000 ALTER TABLE `profitability` DISABLE KEYS */;
INSERT INTO `profitability` (`ticker`, `profitMargin`, `operatingMargin`, `returnOnAssets`, `returnOnEquity`) VALUES ('AAPL',0.21,0.28,0.15,0.36),('AEP',0.55,0.20,0.04,0.11),('CRY',0.62,0.04,0.04,0.03),('CSCO',0.63,0.26,0.09,0.17),('CVX',0.31,0.15,-0.01,-0.01),('JPM',1.00,0.34,0.01,0.10),('MON',0.52,0.18,0.07,0.29),('PNRA',0.33,0.09,0.10,0.30),('RL',0.57,0.08,0.03,0.11),('T',0.54,0.17,0.03,0.11);
/*!40000 ALTER TABLE `profitability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `sectorView`
--

DROP TABLE IF EXISTS `sectorView`;
/*!50001 DROP VIEW IF EXISTS `sectorView`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `sectorView` AS SELECT 
 1 AS `sector`,
 1 AS `avgProfitMargin`,
 1 AS `avgReturnOnEquity`,
 1 AS `avgReturnOnAssets`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'lukeg854_StockData'
--

--
-- Dumping routines for database 'lukeg854_StockData'
--
/*!50003 DROP FUNCTION IF EXISTS `Credit_Rating` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lukeg854`@`localhost` FUNCTION `Credit_Rating`(`ticker` VARCHAR(255)) RETURNS varchar(10) CHARSET utf8
    READS SQL DATA
BEGIN 

DECLARE credit VARCHAR(255);

IF (@totalEquity >= @totalLiabilities) THEN
	SET credit = 'Equitable';
ELSE
	SET credit = 'Levered';
    END IF;
 
RETURN (credit);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Tech_Viewer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lukeg854`@`localhost` PROCEDURE `Tech_Viewer`()
    READS SQL DATA
SELECT * FROM Companies WHERE sector = 'Technology' ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `sectorView`
--

/*!50001 DROP VIEW IF EXISTS `sectorView`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lukeg854`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `sectorView` AS select `c`.`sector` AS `sector`,avg(`p`.`profitMargin`) AS `avgProfitMargin`,avg(`p`.`returnOnEquity`) AS `avgReturnOnEquity`,avg(`p`.`returnOnAssets`) AS `avgReturnOnAssets` from (`Companies` `c` left join `profitability` `p` on((`c`.`ticker` = `p`.`ticker`))) group by `c`.`sector` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 15:58:24
