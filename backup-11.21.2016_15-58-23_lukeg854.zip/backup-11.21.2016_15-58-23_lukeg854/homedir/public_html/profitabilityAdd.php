<?php

require 'connection.php';

$sql = "insert into profitability (ticker, profitMargin, operatingMargin, returnOnAssets, returnOnEquity) VALUES ('" . $_REQUEST["ticker"] . "','" . $_REQUEST["profitMargin"] . "','" . $_REQUEST["operatingMargin"] . "','" . $_REQUEST["returnOnAssets"] . "','" . $_REQUEST["returnOnEquity"] . "')";


if(!$result = $mysqli->query($sql)) {
	echo "Sorry, the website is experiencing problems. ";
	echo "Query: " . $sql . "\n" . "<br>";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}


?>

<script>
window.location ='profitabilityList.php';
</script>



