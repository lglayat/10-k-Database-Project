<?php

require 'connection.php';
require 'menu.php';


$sql = "SELECT * FROM Companies ";
if(!$result = $mysqli->query($sql)) {
	echo "Sorry, the website is experiencing problems. ";
	echo "Query: " . $sql . "\n";
	exit;
}

echo "<table align='center' border=1><th>Companies</th><th>Ticker</th><th>Sector</th><th>Market-Cap</th><th>Operations</th>";
while($Company = $result->fetch_assoc())
	echo "<tr><td>" . $Company["companyName"] . 
	"</td><td> " . $Company["ticker"] . 
	"</td><td> " . $Company["sector"] . 
	"</td><td> " . $Company["marketCap"] . 
	"</td><td><a href='companyDelete.php?companyName=" . $Company["companyName"] . "'>Del</a>  " . 
		 "<a href='companyEdit.php?companyName=" . $Company["companyName"] . "'>Edit</a>" . 
	"</td></tr>";
echo"</table>";



?>

<a href='Companyadd.htm'>Add a Company</a>
<link rel="stylesheet" type="text/css" href="style.css" />
