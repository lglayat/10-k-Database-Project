<form action="companyUpdate.php">

	Company name:
	<input type="text" name = "companyName" value="<?php echo $_REQUEST["companyName"]?>">
	<br>
	Ticker:
	<input type="text" name = "ticker" value="<?php echo $_REQUEST["ticker"]?>">
	<br>
	Sector:
	<select name ="sector">
		<option value='Financial'> Financial</option>
		<option value='Healthcare'> Healthcare</option>
		<option value='Consumer Goods'> Consumer Goods</option>
		<option value='Industrial'>Industrial</option>
		<option value='Basic Materials'> Basic Materials</option>
		<option value='Conglomerates'> Conglomerates</option>
		<option value='Services'> Services</option>
		<option value='Technology'> Technology</option>
		<option value='Utilities'> Utilities</option>
	</select>
	<br>
	Market-Cap Size:
	<select name ="marketCap">
		<option value='Large'> Large</option>
		<option value='Medium'> Medium</option>
		<option value='Small'> Small</option>
	</select>
	<br>
	
	<input type="submit" value="Submit">

</form>