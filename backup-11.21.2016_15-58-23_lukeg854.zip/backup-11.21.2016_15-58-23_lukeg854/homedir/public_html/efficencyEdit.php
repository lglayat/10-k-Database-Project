<form action="efficiencyUpdate.php">

	
	Ticker:
	<input type="text" name = "ticker" value="<?php echo $_REQUEST["ticker"] ?> " >
	<br>
	Asset Turnover:
	<input type="text" name = "assetTurnover" value="<?php echo $_REQUEST["assetTurnover"] ?> " >
	<br>
	Inventory Turnover:
	<input type="text" name = "inventoryTurnover" value="<?php echo $_REQUEST["inventoryTurnover"] ?> " >
	<br>
	Cash Conversion Cycle:
	<input type="text" name = "cashConversionCycle" value="<?php echo $_REQUEST["cashConversionCycle"] ?> " >
	<br>
	
	
	<input type="submit" value="Submit">

</form>