<?php

require 'connection.php';

$sql = "update cashFlows "; 
$sql .= "set ticker = '" . $_REQUEST["ticker"] . "', "; 
$sql .= "operating = '" . $_REQUEST["operating"] . "', ";
$sql .= "financing = '" . $_REQUEST["financing"] . "', ";
$sql .= "investing = '" . $_REQUEST["investing"] . "'";
$sql .= "where ticker ='". $_REQUEST["ticker"] . "'";


if (!$result = $mysqli->query($sql)) {
    	echo "Query: " . $sql . "\n";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}

?>


<script>
window.location = 'cashFlowsList.php';
</script>

