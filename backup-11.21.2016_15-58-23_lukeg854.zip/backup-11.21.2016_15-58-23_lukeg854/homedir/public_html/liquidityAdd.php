<?php

require 'connection.php';

$sql = "insert into liquidity (ticker, currentRatio, quickRatio, debtEquity, debtAssets) VALUES ('" . $_REQUEST["ticker"] . "','" . $_REQUEST["currentRatio"] . "','" . $_REQUEST["quickRatio"] . "','" . $_REQUEST["debtEquity"] . "','" . $_REQUEST["debtAssets"] . "')";


if(!$result = $mysqli->query($sql)) {
	echo "Sorry, the website is experiencing problems. ";
	echo "Query: " . $sql . "\n" . "<br>";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}


?>

<script>
window.location ='liquidityList.php';
</script>

