<form action="incomeStatementUpdate.php">

	
	Ticker:
	<input type="text" name = "ticker" value="<?php echo $_REQUEST["ticker"] ?> " >
	<br>
	Revenue:
	<input type="text" name = "revenue" value="<?php echo $_REQUEST["revenue"] ?> " >
	<br>
	COGS:
	<input type="text" name = "cogs" value="<?php echo $_REQUEST["cogs"] ?> " >
	<br>
	Depreciation:
	<input type="text" name = "depreciation" value="<?php echo $_REQUEST["depreciation"] ?> " >
	<br>
	EBITDA:
	<input type="text" name = "ebitda" value="<?php echo $_REQUEST["ebitda"] ?> " >
	<br>
	Net Income:
	<input type="text" name = "netIncome" value="<?php echo $_REQUEST["netIncome"] ?> " >
	<br>
	
	
	
	<input type="submit" value="Submit">

</form>