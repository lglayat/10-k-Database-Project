
<?php

require 'connection.php';

$sql = "update liquidity "; 
$sql .= "set ticker = '" . $_REQUEST["ticker"] . "', "; 
$sql .= "currentRatio = '" . $_REQUEST["currentRatio"] . "', ";
$sql .= "quickRatio = '" . $_REQUEST["quickRatio"] . "', ";
$sql .= "debtEquity = '" . $_REQUEST["debtEquity"] . "', ";
$sql .= "debtAssets = '" . $_REQUEST["debtAssets"] . "'";
$sql .= "where ticker ='". $_REQUEST["ticker"] . "'";



if (!$result = $mysqli->query($sql)) {
    	echo "Query: " . $sql . "\n";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}

?>


<script>
window.location = 'liquidityList.php';
</script>
