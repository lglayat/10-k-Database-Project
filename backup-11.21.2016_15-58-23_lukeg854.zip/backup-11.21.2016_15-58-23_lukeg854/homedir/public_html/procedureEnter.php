<?php

require 'connection.php';
require 'menu.php';

$sql = "SELECT ticker, Credit_Rating('" . $_REQUEST["ticker"] ."') FROM balanceSheet WHERE ticker ='" . $_REQUEST["ticker"] . "' ";


$creditVal = "SELECT Credit_Rating('" . $_REQUEST["ticker"] . "') FROM balanceSheet WHERE ticker ='" . $_REQUEST["ticker"] . "' ";

$result1 = $mysqli->query($sql);

if(!$result = $mysqli->query($sql)) {
	echo "Query: " . $sql . "\n";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}

//var_dump($result);


echo "<table align='center' border=1><th>Ticker</th><th>Capital Structure</th>";
while($function = $result->fetch_assoc())
	echo "<tr><td>" . $function["ticker"] . 
	"</td><td> " . $function[1] . 
	"</td></tr>";
echo"</table>";




?>