<?php

require 'connection.php';
require 'menu.php';


$sql = "SELECT * FROM sectorView ";
if(!$result = $mysqli->query($sql)) {
	echo "Sorry, the website is experiencing problems. ";
	echo "Query: " . $sql . "\n";
	exit;
}

echo "<table align='center' border=1><th>Sector</th><th>Profit Margin BM</th><th>ROE BM</th><th>ROA BM</th>";
while($sectorView = $result->fetch_assoc())
	echo 
	"<tr><td>  " . $sectorView["sector"] . 
	"</td><td> " . $sectorView["avgProfitMargin"] . 
	"</td><td> " . $sectorView["avgReturnOnEquity"] . 
	"</td><td> " . $sectorView["avgReturnOnAssets"] . 
	"</td></tr>";
echo"</table>";



?>

<link rel="stylesheet" type="text/css" href="style.css" />
