<?php

require 'connection.php';

$sql = "insert into cashFlows (ticker, operating, financing, investing) VALUES ('" . $_REQUEST["ticker"] . "','" . $_REQUEST["operating"] . "','" . $_REQUEST["financing"] . "','" . $_REQUEST["investing"] . "')";


if(!$result = $mysqli->query($sql)) {
	echo "Sorry, the website is experiencing problems. ";
	echo "Query: " . $sql . "\n" . "<br>";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}


?>

<script>
window.location ='cashFlowsList.php';
</script>


