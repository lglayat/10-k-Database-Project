<?php

require 'connection.php';

$sql = "insert into balanceSheet (ticker, totalAssets, totalEquity, totalLiabilities) VALUES ('" . $_REQUEST["ticker"] . "','" . $_REQUEST["totalAssets"] . "','" . $_REQUEST["totalEquity"] . "','" . $_REQUEST["totalLiabilities"] . "')";


if(!$result = $mysqli->query($sql)) {
	echo "Sorry, the website is experiencing problems. ";
	echo "Query: " . $sql . "\n" . "<br>";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}


?>

<script>
window.location ='balanceSheetList.php';
</script>



