<?php

require 'connection.php';
require 'menu.php';


$sql = "SELECT * FROM incomeStatement ";
if(!$result = $mysqli->query($sql)) {
	echo "Sorry, the website is experiencing problems. ";
	echo "Query: " . $sql . "\n";
	exit;
}

echo "<table align='center' border=1><th>Ticker</th><th>Revenue</th><th>COGS</th><th>Depreciation</th><th>EBITDA</th><th>NetIncome</th><th>Operations</th>";
while($incomeStatement = $result->fetch_assoc())
	echo "<tr><td>" . $incomeStatement["ticker"] . 
	"</td><td> " . $incomeStatement["revenue"] . 
	"</td><td> " . $incomeStatement["cogs"] . 
	"</td><td> " . $incomeStatement["depreciation"] . 
	"</td><td> " . $incomeStatement["ebitda"] . 
	"</td><td> " . $incomeStatement["netIncome"] . 
	"</td><td>
		  <a href='incomeStatementDelete.php?ticker=" . $incomeStatement["ticker"] . "'>Del</a>  " . 
		 "<a href='incomeStatementEdit.php?ticker=" . $incomeStatement["ticker"] . "'>Edit</a>" . 
	"</td></tr>";
echo"</table>";



?>

<a href='incomeStatementAdd.htm'>Add a Company's Income Statement</a>
<link rel="stylesheet" type="text/css" href="style.css" />

