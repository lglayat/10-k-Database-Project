<form action="cashFlowsUpdate.php">

	
	Ticker:
	<input type="text" name = "ticker" value="<?php echo $_REQUEST["ticker"] ?> " >
	<br>
	Operating:
	<input type="text" name = "operating" value="<?php echo $_REQUEST["operating"] ?> " >
	<br>
	Financing:
	<input type="text" name = "financing" value="<?php echo $_REQUEST["financing"] ?> " >
	<br>
	Investing:
	<input type="text" name = "investing" value="<?php echo $_REQUEST["investing"] ?> " >
	<br>
	
	
	<input type="submit" value="Submit">

</form>