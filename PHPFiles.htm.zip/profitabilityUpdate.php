<?php

require 'connection.php';

$sql = "update profitability "; 
$sql .= "set ticker = '" . $_REQUEST["ticker"] . "', "; 
$sql .= "profitMargin = '" . $_REQUEST["profitMargin"] . "', ";
$sql .= "operatingMargin = '" . $_REQUEST["operatingMargin"] . "', ";
$sql .= "returnOnAssets = '" . $_REQUEST["returnOnAssets"] . "', ";
$sql .= "returnOnEquity = '" . $_REQUEST["returnOnEquity"] . "'";
$sql .= "where ticker ='". $_REQUEST["ticker"] . "'";



if (!$result = $mysqli->query($sql)) {
    	echo "Query: " . $sql . "\n";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}

?>


<script>
window.location = 'profitabilityList.php';
</script>
