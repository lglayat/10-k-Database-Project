<?php

require 'connection.php';

$sql = "update efficiency "; 
$sql .= "set ticker = '" . $_REQUEST["ticker"] . "', "; 
$sql .= "assetTurnover = '" . $_REQUEST["assetTurnover"] . "', ";
$sql .= "inventoryTurnover = '" . $_REQUEST["inventoryTurnover"] . "', ";
$sql .= "cashConversionCycle = '" . $_REQUEST["cashConversionCycle"] . "'";
$sql .= "where ticker ='". $_REQUEST["ticker"] . "'";


if (!$result = $mysqli->query($sql)) {
    	echo "Query: " . $sql . "\n";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}

?>


<script>
window.location = 'efficiencyList.php';
</script>
