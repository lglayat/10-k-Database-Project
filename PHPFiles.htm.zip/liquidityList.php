<?php

require 'connection.php';
require 'menu.php';


$sql = "SELECT * FROM liquidity ";
if(!$result = $mysqli->query($sql)) {
	echo "Sorry, the website is experiencing problems. ";
	echo "Query: " . $sql . "\n";
	exit;
}

echo "<table align='center' border=1><th>Ticker</th><th>Current Ratio</th><th>Quick Ratio</th><th>Debt/Equity</th><th>Debt/Asset</th><th>Operations</th>";
while($liquidity = $result->fetch_assoc())
	echo "<tr><td>" . $liquidity["ticker"] . 
	"</td><td> " . $liquidity["currentRatio"] . 
	"</td><td> " . $liquidity["quickRatio"] . 
	"</td><td> " . $liquidity["debtEquity"] . 
	"</td><td> " . $liquidity["debtAssets"] . 
	"</td><td><a href='liquidityDelete.php?ticker=" . $liquidity["ticker"] . "'>Del</a>  " . 
		 "<a href='liquidityEdit.php?ticker=" . $liquidity["ticker"] . "'>Edit</a>" . 
	"</td></tr>";
echo"</table>";



?>

<a href='liquidityAdd.htm'>Add a Company's Liquidity Ratios</a>
<link rel="stylesheet" type="text/css" href="style.css" />
