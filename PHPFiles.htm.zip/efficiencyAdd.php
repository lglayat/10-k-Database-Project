<?php

require 'connection.php';

$sql = "insert into efficiency (ticker, assetTurnover, inventoryTurnover, cashConversionCycle) VALUES ('" . $_REQUEST["ticker"] . "','" . $_REQUEST["assetTurnover"] . "','" . $_REQUEST["inventoryTurnover"] . "','" . $_REQUEST["cashConversionCycle"] . "')";


if(!$result = $mysqli->query($sql)) {
	echo "Sorry, the website is experiencing problems. ";
	echo "Query: " . $sql . "\n" . "<br>";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}


?>

<script>
window.location ='efficiencyList.php';
</script>
