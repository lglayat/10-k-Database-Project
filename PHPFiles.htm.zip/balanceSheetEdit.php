<form action="balanceSheetUpdate.php">

	
	Ticker:
	<input type="text" name = "ticker" value="<?php echo $_REQUEST["ticker"] ?> " >
	<br>
	Total Assets:
	<input type="text" name = "totalAssets" value="<?php echo $_REQUEST["totalAssets"] ?> " >
	<br>
	Total Equity:
	<input type="text" name = "totalEquity" value="<?php echo $_REQUEST["totalEquity"] ?> " >
	<br>
	Total Liabilities:
	<input type="text" name = "totalLiabilities" value="<?php echo $_REQUEST["totalLiabilities"] ?> " >
	<br>
	
	
	<input type="submit" value="Submit">

</form>