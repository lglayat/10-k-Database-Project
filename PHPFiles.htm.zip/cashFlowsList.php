<?php

require 'connection.php';
require 'menu.php';


$sql = "SELECT * FROM cashFlows ";
if(!$result = $mysqli->query($sql)) {
	echo "Sorry, the website is experiencing problems. ";
	echo "Query: " . $sql . "\n";
	exit;
}

echo "<table align='center' border=1><th>Ticker</th><th>Operating</th><th>Investing</th><th>Financing</th><th>Operations</th>";
while($cashFlows = $result->fetch_assoc())
	echo "<tr><td>" . $cashFlows["ticker"] . 
	"</td><td> " . $cashFlows["operating"] . 
	"</td><td> " . $cashFlows["investing"] . 
	"</td><td> " . $cashFlows["financing"] . 
	"</td><td><a href='cashFlowsDelete.php?ticker=" . $cashFlows["ticker"] . "'>Del</a>  " . 
		 "<a href='cashFlowsEdit.php?ticker=" . $cashFlows["ticker"] . "'>Edit</a>" . 
	"</td></tr>";
echo"</table>";



?>

<a href='cashFlowsAdd.html'>Add a Company's Statement Of Cash Flows</a>
<link rel="stylesheet" type="text/css" href="style.css" />

