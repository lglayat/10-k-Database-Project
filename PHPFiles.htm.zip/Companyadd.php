<?php

require 'connection.php';

$sql = "insert into Companies (companyName, ticker, sector, marketCap) VALUES ('" . $_REQUEST["companyName"] . "','" . $_REQUEST["ticker"] . "','" . $_REQUEST["sector"] . "','" . $_REQUEST["marketCap"] . "')";


if(!$result = $mysqli->query($sql)) {
	echo "Sorry, the website is experiencing problems. ";
	echo "Query: " . $sql . "\n" . "<br>";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}



?>

<script>
window.location ='Companylist.php';
</script>


