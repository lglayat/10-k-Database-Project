<?php

require 'connection.php';

$sql = "update incomeStatement "; 
$sql .= "set ticker ='" . $_REQUEST["ticker"] . "', "; 
$sql .= "revenue = '" . $_REQUEST["revenue"] . "', ";
$sql .= "cogs = '" . $_REQUEST["cogs"] . "', ";
$sql .= "depreciation = '" . $_REQUEST["depreciation"] . "',";
$sql .= "ebitda = '" . $_REQUEST["ebitda"] . "',";
$sql .= "netIncome = '" . $_REQUEST["netIncome"] . "'";
$sql .= "where ticker ='". $_REQUEST["ticker"] . "'";


if (!$result = $mysqli->query($sql)) {
    	echo "Query: " . $sql . "\n";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}

?>


<script>
window.location = 'incomeStatementList.php';
</script>

