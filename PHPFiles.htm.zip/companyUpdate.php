<?php

require 'connection.php';

$sql = "update Companies "; 
$sql .= "set companyName = '" . $_REQUEST["companyName"] . "', "; 
$sql .= "ticker = '" . $_REQUEST["ticker"] . "', ";
$sql .= "sector = '" . $_REQUEST["sector"] . "', ";
$sql .= "marketCap = '" . $_REQUEST["marketCap"] . "'";
$sql .= "where companyName ='". $_REQUEST["companyName"] . "'";


if (!$result = $mysqli->query($sql)) {
    	echo "Query: " . $sql . "\n";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}

?>


<script>
window.location = 'Companylist.php';
</script>

