<?php

require 'connection.php';

$sql = "insert into incomeStatement (ticker, revenue, cogs, depreciation, ebitda, netIncome) VALUES ('" . $_REQUEST["ticker"] . "','" . $_REQUEST["revenue"] . "','" . $_REQUEST["cogs"] . "','" . $_REQUEST["depreciation"] . "','" . $_REQUEST["ebitda"] ."','" . $_REQUEST["netIncome"] . "')";


if(!$result = $mysqli->query($sql)) {
	echo "Sorry, the website is experiencing problems. ";
	echo "Query: " . $sql . "\n" . "<br>";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}


?>

<script>
window.location ='incomeStatementList.php';
</script>



