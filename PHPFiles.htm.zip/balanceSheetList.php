<?php

require 'connection.php';
require 'menu.php';


$sql = "SELECT * FROM balanceSheet ";
if(!$result = $mysqli->query($sql)) {
	echo "Sorry, the website is experiencing problems. ";
	echo "Query: " . $sql . "\n";
	exit;
}

echo "<table align='center' border=1><th>Ticker</th><th>Total Assets</th><th>Total Equity</th><th>Total Liabilities</th><th>Operations</th>";
while($balanceSheet = $result->fetch_assoc())
	echo "<tr><td>" . $balanceSheet["ticker"] . 
	"</td><td> " . $balanceSheet["totalAssets"] . 
	"</td><td> " . $balanceSheet["totalEquity"] . 
	"</td><td> " . $balanceSheet["totalLiabilities"] . 
	"</td><td><a href='balanceSheetDelete.php?ticker=" . $balanceSheet["ticker"] . "'>Del</a>  " . 
		 "<a href='balanceSheetEdit.php?ticker=" . $balanceSheet["ticker"] . "'>Edit</a>" . 
	"</td></tr>";
echo"</table>";



?>

<a href='balanceSheetAdd.htm'>Add a Company's Balance Sheet</a>
<link rel="stylesheet" type="text/css" href="style.css" />

