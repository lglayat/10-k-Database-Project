<?php

require 'connection.php';
require 'menu.php';


$sql = "SELECT * FROM efficiency ";
if(!$result = $mysqli->query($sql)) {
	echo "Sorry, the website is experiencing problems. ";
	echo "Query: " . $sql . "\n";
	exit;
}

echo "<table align='center' border=1><th>Ticker</th><th>Asset Turnover</th><th>Inventory Turnover</th><th>Cash Conversion Cycle</th><th>Operations</th>";
while($efficiency = $result->fetch_assoc())
	echo "<tr><td>" . $efficiency["ticker"] . 
	"</td><td> " . $efficiency["assetTurnover"] . 
	"</td><td> " . $efficiency["inventoryTurnover"] . 
	"</td><td> " . $efficiency["cashConversionCycle"] . 
	"</td><td><a href='efficiencyDelete.php?ticker=" . $efficiency["ticker"] . "'>Del</a>  " . 
		 "<a href='efficiencyEdit.php?ticker=" . $efficiency["ticker"] . "'>Edit</a>" . 
	"</td></tr>";
echo"</table>";



?>

<a href='efficiencyAdd.html'>Add a Company's Statement Of Efficiency Ratios</a>

<link rel="stylesheet" type="text/css" href="style.css" />
