<form action="liquidityUpdate.php">

	
	Ticker:
	<input type="text" name = "ticker" value="<?php echo $_REQUEST["ticker"] ?> " >
	<br>
	Current Ratio:
	<input type="text" name = "currentRatio" value="<?php echo $_REQUEST["currentRatio"] ?> " >
	<br>
	Quick Ratio:
	<input type="text" name = "quickRatio" value="<?php echo $_REQUEST["quickRatio"] ?> " >
	<br>
	Debt/Equity:
	<input type="text" name = "debtEquity" value="<?php echo $_REQUEST["debtEquity"] ?> " >
	<br>
	Debt/Assets:
	<input type="text" name = "debtAssets" value="<?php echo $_REQUEST["debtAssets"] ?> " >
	<br>
	
	
	<input type="submit" value="Submit">

</form>