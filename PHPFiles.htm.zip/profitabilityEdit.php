<form action="profitabilityUpdate.php">

	
	Ticker:
	<input type="text" name = "ticker" value="<?php echo $_REQUEST["ticker"]?>" >
	<br>
	Profit Margin:
	<input type="text" name = "profitMargin" value="<?php echo $_REQUEST["profitMargin"]?>" >
	<br>
	Operating Margin:
	<input type="text" name = "operatingMargin" value="<?php echo $_REQUEST["operatingMargin"]?>" >
	<br>
	Return On Assets:
	<input type="text" name = "returnOnAssets" value="<?php echo $_REQUEST["returnOnAssets"]?>" >
	<br>
	Return On Equity:
	<input type="text" name = "returnOnEquity" value="<?php echo $_REQUEST["returnOnEquity"]?>" >
	<br>
	
	
	<input type="submit" value="Submit">

</form>