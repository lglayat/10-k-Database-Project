<?php

require 'connection.php';
require 'menu.php';


$sql = "SELECT * FROM profitability ";
if(!$result = $mysqli->query($sql)) {
	echo "Sorry, the website is experiencing problems. ";
	echo "Query: " . $sql . "\n";
	exit;
}

echo "<table align='center' border=1><th>Ticker</th><th>Profit Margin</th><th>Operating Margin</th><th>ROA</th><th>ROE</th><th>Operations</th>";
while($profitability = $result->fetch_assoc())
	echo "<tr><td>" . $profitability["ticker"] . 
	"</td><td> " . $profitability["profitMargin"] . 
	"</td><td> " . $profitability["operatingMargin"] . 
	"</td><td> " . $profitability["returnOnAssets"] . 
	"</td><td> " . $profitability["returnOnEquity"] . 
	"</td><td><a href='profitabilityDelete.php?ticker=" . $profitability["ticker"] . "'>Del</a>  " . 
		 "<a href='profitabilityEdit.php?ticker=" . $profitability["ticker"] . "'>Edit</a>" . 
	"</td></tr>";
echo"</table>";



?>

<a href='profitabilityAdd.htm'>Add a Company's Profitability Ratios</a>
<link rel="stylesheet" type="text/css" href="style.css" />

