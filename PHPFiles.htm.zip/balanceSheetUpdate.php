<?php

require 'connection.php';

$sql = "update balanceSheet "; 
$sql .= "set ticker = '" . $_REQUEST["ticker"] . "', "; 
$sql .= "totalAssets = '" . $_REQUEST["totalAssets"] . "', ";
$sql .= "totalLiabilities = '" . $_REQUEST["totalLiabilities"] . "', ";
$sql .= "totalEquity = '" . $_REQUEST["totalEquity"] . "'";
$sql .= "where ticker ='". $_REQUEST["ticker"] . "'";


if (!$result = $mysqli->query($sql)) {
    	echo "Query: " . $sql . "\n";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}

?>


<script>
window.location = 'balanceSheetList.php';
</script>

