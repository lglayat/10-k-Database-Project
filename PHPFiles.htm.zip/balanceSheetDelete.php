<?php

require 'connection.php';


$sql = "DELETE FROM balanceSheet where ticker ='" . $_REQUEST["ticker"] . "'";
if(!$result = $mysqli->query($sql)) {
	echo "Query: " . $sql . "\n";
	echo "errno: " . $mysqli->errno . "<br>";
	echo "error: " . $mysqli->error . "<br>";
	exit;
}



?>

<script>
window.location = 'balanceSheetList.php';
</script>
